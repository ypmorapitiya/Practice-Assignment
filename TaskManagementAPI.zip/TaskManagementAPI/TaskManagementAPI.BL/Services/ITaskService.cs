﻿using TaskManagementAPI.DAL.Models.DTO;
using TaskManagementAPI.DAL.Response;

namespace TaskManagementAPI.BL.Services
{
    public interface ITaskService
    {
        Task<RepositoryResponse<string>> AddTask(TaskN task);
        Task<RepositoryResponse<string>> DeleteTask(int id);
        Task<RepositoryResponse<List<TaskN>>> GetAllTask(string id);
        Task<RepositoryResponse<TaskN>> GetTask(int id);
        Task<RepositoryResponse<string>> UpdateTask(TaskN task, int id);
        Task<RepositoryResponse<string>> CompleteTask(int id);
    }
}