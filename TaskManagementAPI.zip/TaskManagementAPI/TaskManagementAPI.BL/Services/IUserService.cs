﻿using TaskManagementAPI.DAL.Models.DTO;
using TaskManagementAPI.DAL.Response;

namespace TaskManagementAPI.BL.Services
{
    public interface IUserService
    {
        Task<RepositoryResponse<TokenResponse>> LogIn(LogInUser user);
        Task<RepositoryResponse<string>> Register(RegisterUser user);
    }
}