﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TaskManagementAPI.DAL.Models.Domain;
using TaskManagementAPI.DAL.Models.DTO;
using TaskManagementAPI.DAL.Repositories;
using TaskManagementAPI.DAL.Response;

namespace TaskManagementAPI.BL.Services
{
    public class TaskService : ITaskService
    {
        private readonly ITaskRepository taskRepositiry;

        public TaskService(ITaskRepository taskRepositiry)
        {
            this.taskRepositiry = taskRepositiry;
        }

        public async Task<RepositoryResponse<string>> AddTask(TaskN task)
        {
            var newTask = new UserTask()
            {
                TaskDescription = task.TaskDescription,
                TaskName = task.TaskName,
                UserId = task.UserId,
            };
            var response = await taskRepositiry.AddTask(newTask);
            return response;
        }


        public async Task<RepositoryResponse<string>> UpdateTask(TaskN task, int id)
        {
            var newTask = new UserTask()
            {
                TaskDescription = task.TaskDescription,
                TaskName = task.TaskName,
                UserId = task.UserId,
            };
            var response = await taskRepositiry.UpdateTask(newTask, id);
            return response;
        }

        public async Task<RepositoryResponse<string>> DeleteTask(int id)
        {

            var response = await taskRepositiry.DeleteTask(id);
            return response;
        }

        public async Task<RepositoryResponse<TaskN>> GetTask(int id)
        {
            var newResponse = new RepositoryResponse<TaskN>();
            var response = await taskRepositiry.GetTaskById(id);
            if (response.Status)
            {
                newResponse.Status = true;
                newResponse.Message = response.Message;
                newResponse.Data = new TaskN()
                {
                    TaskName = response.Data.TaskName,
                    UserId = response.Data.UserId,
                    TaskDescription = response.Data.TaskDescription,
                    TaskStatus = response.Data.TaskStatus,
                    TaskId = response.Data.TaskId
                };
                return newResponse;
            }
            newResponse.Status = response.Status;
            newResponse.Message = response.Message;

            return newResponse;
        }
        public async Task<RepositoryResponse<List<TaskN>>> GetAllTask(string id)
        {
            var newResponse = new RepositoryResponse<List<TaskN>>();
            var response = await taskRepositiry.GetAllTasks(id);
            if (response.Status)
            {
                newResponse.Status = true;
                newResponse.Message = response.Message;
                var taskList = new List<TaskN>();
                foreach (var r in response.Data)
                {
                    var s = new TaskN()
                    {
                        TaskName = r.TaskName,
                        UserId = r.UserId,
                        TaskDescription = r.TaskDescription,
                        TaskStatus = r.TaskStatus,
                        TaskId = r.TaskId
                    };
                    taskList.Add(s);
                }
                
                newResponse.Data = taskList;
                return newResponse;
            }
            newResponse.Status = response.Status;
            newResponse.Message = response.Message;

            return newResponse;
        }

        public async Task<RepositoryResponse<string>> CompleteTask( int id)
        {
            
            var response = await taskRepositiry.CompleteTask( id);
            return response;
        }
    }
}
