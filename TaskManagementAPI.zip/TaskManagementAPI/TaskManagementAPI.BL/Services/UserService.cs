﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TaskManagementAPI.DAL.Models.Domain;
using TaskManagementAPI.DAL.Models.DTO;
using TaskManagementAPI.DAL.Repositories;
using TaskManagementAPI.DAL.Response;

namespace TaskManagementAPI.BL.Services
{
    public class UserService : IUserService
    {
        private readonly IUserRepository userRepositiry;

        public UserService(IUserRepository userRepositiry)
        {
            this.userRepositiry = userRepositiry;
        }

        public async Task<RepositoryResponse<string>> Register(RegisterUser user)
        {
            var newUser = new NewUser()
            {
                FullName = user.FullName,
                Email = user.Email,
                Password = user.Password
            };

            var response = await userRepositiry.Register(newUser);

            return response;
        }

        public async Task<RepositoryResponse<TokenResponse>> LogIn(LogInUser user)
        {
            var loginUser = new SignInUser()
            {

                UserName = user.UserName,
                Password = user.Password
            };

            var response = await userRepositiry.Login(loginUser);

            return response;
        }
    }
}
