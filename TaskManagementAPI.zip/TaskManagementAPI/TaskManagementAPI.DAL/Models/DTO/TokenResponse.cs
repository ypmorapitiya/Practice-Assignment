﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaskManagementAPI.DAL.Models.DTO
{
    public class TokenResponse
    {
        public string JWT { get; set; }
       
        public string User_Id { get; set; }
    }
}
