﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaskManagementAPI.DAL.Models.Domain
{
    public class JWTSetting
    {
        public string securitykey { get; set; }
    }
}
