﻿using TaskManagementAPI.DAL.Models.Domain;
using TaskManagementAPI.DAL.Response;

namespace TaskManagementAPI.DAL.Repositories
{
    public interface ITaskRepository
    {
        Task<RepositoryResponse<string>> AddTask(UserTask addTask);
        Task<RepositoryResponse<string>?> CompleteTask(int id);
        Task<RepositoryResponse<string>> DeleteTask(int id);
        Task<RepositoryResponse<List<UserTask>>?> GetAllTasks(string userId);
        Task<RepositoryResponse<UserTask>?> GetTaskById(int id);
        Task<RepositoryResponse<string>> UpdateTask(UserTask newTask, int id);
    }
}