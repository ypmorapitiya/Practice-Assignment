﻿using TaskManagementAPI.DAL.Models.Domain;
using TaskManagementAPI.DAL.Models.DTO;
using TaskManagementAPI.DAL.Response;

namespace TaskManagementAPI.DAL.Repositories
{
    public interface IUserRepository
    {
        Task<RepositoryResponse<TokenResponse>> Login(SignInUser loginUser);
        Task<RepositoryResponse<string>> Register(NewUser user);
    }
}