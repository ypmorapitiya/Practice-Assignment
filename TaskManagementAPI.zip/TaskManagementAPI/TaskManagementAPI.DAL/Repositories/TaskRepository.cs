﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TaskManagementAPI.DAL.DBcontext;
using TaskManagementAPI.DAL.Models.Domain;
using TaskManagementAPI.DAL.Response;

namespace TaskManagementAPI.DAL.Repositories
{
    public class TaskRepository : ITaskRepository
    {
        private readonly TaskDbContext taskDbContext;

        public TaskRepository(TaskDbContext taskDbContext)
        {
            this.taskDbContext = taskDbContext;
        }

        public async Task<RepositoryResponse<string>> AddTask(UserTask addTask)
        {
            var response = new RepositoryResponse<string>();
            try
            {
                if (addTask != null)
                {
                    taskDbContext.Tasks.Add(addTask);
                    await taskDbContext.SaveChangesAsync();
                    response.Status = true;
                    response.Message = "Task Added";

                    return response;
                }
                else
                {
                    response.Status = false;
                    response.Message = "adding faild";
                    return response;
                }
            }
            catch (Exception ex)
            {
                response.Status = false;
                response.Message = "adding faild";
                response.Data = ex.Message;
            }
            return response;

        }

        public async Task<RepositoryResponse<string>> UpdateTask(UserTask newTask, int id)
        {
            var response = new RepositoryResponse<string>();
            try
            {
                var exTask = await taskDbContext.Tasks.FindAsync(id);
                if (exTask != null)
                {
                    exTask.TaskName = newTask.TaskName;
                    exTask.TaskDescription = newTask.TaskDescription;
                    exTask.TaskStatus = newTask.TaskStatus;

                    taskDbContext.Tasks.Update(exTask);
                    await taskDbContext.SaveChangesAsync();

                    response.Status = true;
                    response.Message = "updated successfully";
                    return response;

                }
                response.Status = false;
                response.Message = "no task with this Id";
                return response;
            }
            catch (Exception ex)
            {
                response.Status = false;
                response.Message = "no task deleted";
                response.Data = ex.Message;
                return response;
            }
        }

        public async Task<RepositoryResponse<string>> DeleteTask(int id)
        {
            var response = new RepositoryResponse<string>();
            try
            {
                var exTask = await taskDbContext.Tasks.FindAsync(id);
                if (exTask != null)
                {
                    taskDbContext.Tasks.Remove(exTask);
                    await taskDbContext.SaveChangesAsync();
                    response.Status = true;
                    response.Message = "task deleted";

                    return response;
                }
                else
                {
                    response.Status = false;
                    response.Message = "no Task to delete";
                    return response;
                }

            }
            catch (Exception ex)
            {
                response.Status = false;
                response.Message = "task not deleted";
                response.Data = ex.Message;
                return response;
            }
        }

        public async Task<RepositoryResponse<UserTask>?> GetTaskById(int id)
        {
            var response = new RepositoryResponse<UserTask>();
            try
            {
                var exTask = await taskDbContext.Tasks.FindAsync(id);
                if (exTask == null)
                {
                    response.Status = false;
                    response.Message = "task unavailable";
                    return response;
                }
                response.Status = true;
                response.Message = "task available";
                response.Data = exTask;
                return response;
            }
            catch (Exception ex)
            {
                response.Status = false;
                response.Message = "somthing went wrong- " + ex.Message;

                return response;
            }
        }

        public async Task<RepositoryResponse<List<UserTask>>?> GetAllTasks(string userId)
        {
            var response = new RepositoryResponse<List<UserTask>>();
            try
            {
                var tasks = await taskDbContext.Tasks.Where(e => e.UserId == userId).ToListAsync();

                if (tasks == null)
                {
                    response.Status = false;
                    response.Message = "task unavailable";
                    return response;
                }
                response.Status = true;
                response.Message = "tasks available";
                response.Data = tasks;
                return response;
            }
            catch (Exception ex)
            {
                response.Status = false;
                response.Message = "somthing went wrong- " + ex.Message;

                return response;
            }
        }

        public async Task<RepositoryResponse<string>?> CompleteTask(int id)
        {
            var response = new RepositoryResponse<string>();
            try
            {
                var exTask = await taskDbContext.Tasks.FindAsync(id);

                if (exTask == null)
                {
                    response.Status = false;
                    response.Message = "task unavailable";
                    return response;
                }
                exTask.TaskStatus = true;
                await taskDbContext.SaveChangesAsync();
                response.Status = true;
                response.Message = "tasks completed";

                return response;
            }
            catch (Exception ex)
            {
                response.Status = false;
                response.Message = "somthing went wrong ";
                response.Data = ex.Message;

                return response;
            }
        }

    }
}
