﻿using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using TaskManagementAPI.DAL.DBcontext;
using TaskManagementAPI.DAL.Models.Domain;
using TaskManagementAPI.DAL.Models.DTO;
using TaskManagementAPI.DAL.Response;

namespace TaskManagementAPI.DAL.Repositories
{
    public class UserRepository : IUserRepository
    {
        private readonly UserManager<User> userManager;
        private readonly IConfiguration configuration;
        private readonly TaskDbContext taskDbContext;
        private readonly JWTSetting jwtSetting;

        public UserRepository(UserManager<User> userManager, IOptions<JWTSetting> options, TaskDbContext taskDbContext)
        {
            this.userManager = userManager;

            this.configuration = configuration;
            this.taskDbContext = taskDbContext;
            this.jwtSetting = options.Value;
        }

        public async Task<RepositoryResponse<string>> Register(NewUser user)
        {

            var response = new RepositoryResponse<string>();
            try
            {
                User newUser = new()
                {
                    FullName = user.FullName,
                    UserName = user.Email,
                    Email = user.Email,
                    SecurityStamp = Guid.NewGuid().ToString(),
                };
                var result = await userManager.CreateAsync(newUser, user.Password);
                if (result.Succeeded)
                {
                    response.Status = true;
                    response.Message = "User Added";
                }
                else
                {
                    response.Status = false;
                    response.Message = "registration faild";
                    response.Data = result.ToString();
                }


            }
            catch (Exception ex)
            {
                response.Status = false;
                response.Message = "registration faild";
                response.Data = ex.Message;
            }
            return response;

        }


        public async Task<RepositoryResponse<TokenResponse>> Login(SignInUser loginUser)
        {
            var response = new RepositoryResponse<TokenResponse>();
            try
            {
                var user = await userManager.FindByEmailAsync(loginUser.UserName);
                if (user != null && await userManager.CheckPasswordAsync(user, loginUser.Password))
                {

                    var tokenhandler = new JwtSecurityTokenHandler();
                    var tokenkey = Encoding.UTF8.GetBytes(jwtSetting.securitykey);
                    var tokenDescriptor = new SecurityTokenDescriptor
                    {
                        Subject = new ClaimsIdentity(
                            new Claim[]
                            {
                             new Claim(ClaimTypes.Email, user.Email),
                            }
                        ),
                        Expires = DateTime.Now.AddMinutes(20),
                        SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(tokenkey), SecurityAlgorithms.HmacSha256)
                    };
                    var token = tokenhandler.CreateToken(tokenDescriptor);
                    string finaltoken = tokenhandler.WriteToken(token);

                    var tokenWithId = new TokenResponse() { JWT = finaltoken, User_Id= user.Id};
                    response.Status = true;
                    response.Message = "User Logged successfuly";
                    response.Data = tokenWithId;

                    return response;
                }
                else
                {
                    response.Status = false;
                    response.Message = "Invalid Credintials";

                }
            }
            catch (Exception ex)
            {
                response.Status = false;
                response.Message = ex.Message;
                return response;
            }
            return response;
        }
    }
}
