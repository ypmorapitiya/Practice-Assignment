﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TaskManagementAPI.BL.Services;
using TaskManagementAPI.DAL.Models.DTO;

namespace TaskManagementAPI.WEB.Controllers
{
    [EnableCors("MyPolicy")]
    [Route("[controller]")]
    [Authorize]
    [ApiController]
    public class TaskController : Controller
    {
        private readonly ITaskService taskService;

        public TaskController(ITaskService taskService)
        {
            this.taskService = taskService;
        }

        [HttpPost]
        [Route("addtask")]
        public async Task<IActionResult> AddTask(TaskN newTask)
        {
            if (newTask != null)
            {
              
               var response = await taskService.AddTask(newTask);
               return Ok(response);
            }

            return BadRequest("Error in adding a task");
        }

        [HttpPut]
        [Route("updateTask/{id}")]
        public async Task<IActionResult> UpdateTask([FromBody] TaskN task, int id = 0)
        {
           
            var response = await taskService.UpdateTask(task, id);
            if (response.Status == true)
            {
                return Ok(new { response.Message });
            }
            return BadRequest(new { response.Message });
        }

        [HttpDelete]
        [Route("deleteTask/{id}")]
        public async Task<IActionResult> DeleteTask(int id = 0)
        {
            if (id == 0) { return BadRequest(new { message = "id required" }); }
            var response = await taskService.DeleteTask(id);
            if (response.Status == true)
            {
                return Ok(new { response.Message });
            }
            return BadRequest(new { response.Message });
        }

        [HttpGet]
        [Route("getTask/{id}")]
        public async Task<IActionResult> getTask(int id = 0)
        {
            if (id == 0) { return BadRequest(new { message = "id required" }); }
            var response = await taskService.GetTask(id);
            if (response.Status)
            {
                return Ok(response);
            }
            return BadRequest(response);
        }

        [HttpGet]
        [Route("getAllTasks/{id}")]
        public async Task<IActionResult> getAllTasks(string id)
        {

            var response = await taskService.GetAllTask(id);
            if (response.Status)
            {
                return Ok(response);
            }
            return BadRequest(response);
        }


        [HttpGet]
        [Route("completeTask/{id}")]
        public async Task<IActionResult> UpdateTask( int id = 0)
        {
             var response = await taskService.CompleteTask( id);
            if (response.Status == true)
            {
                return Ok(new { response.Message });
            }
            return BadRequest(new { response.Message });
        }
    }
}
