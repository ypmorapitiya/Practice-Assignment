﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using TaskManagementAPI.BL.Services;
using TaskManagementAPI.DAL.Models.DTO;

namespace TaskManagementAPI.WEB.Controllers
{
    [EnableCors("MyPolicy")]
    [Route("[controller]")]
    [ApiController]
    public class UserController : Controller
    {
        private readonly IUserService userService;

        public UserController(IUserService userService)
        {
            this.userService = userService;
        }
        [HttpPost]
        [Route("register")]
        public async Task<IActionResult> Register( RegisterUser newUser)
        {
            if (!ModelState.IsValid) {
                return BadRequest("all fields are required");
            }
          var result = await userService.Register(newUser);

            return Ok(result);
        }


        [HttpPost]
        [Route("login")]
        public async Task<IActionResult> Login([FromBody] LogInUser loginUser)
        {

            if (!ModelState.IsValid)
            {
                return BadRequest(new { error = "not valid creditial" });
            }

            var tokenresponse = await userService.LogIn(loginUser);
            if (tokenresponse == null)
            {
                return Unauthorized(new { error = "not valid creditial" });
            }
            return Ok(tokenresponse);


        }
    }
}
