import { Component } from '@angular/core';
import { Task } from 'src/app/models/task.model';
import { AuthService } from 'src/app/services/auth.service';
import { ToastrService } from 'ngx-toastr';
import { ActivatedRoute, Router } from '@angular/router';
@Component({
  selector: 'app-add-task',
  templateUrl: './add-task.component.html',
  styleUrls: ['./add-task.component.css'],
})
export class AddTaskComponent {
  minDate: any;
  taskId:any
  userId:any
  newTask: Task = {
    taskId: 0,
    taskName: '',
    taskDescription: '',
    userId:'',
    taskStatus:false
  };
  constructor(private api: AuthService,private url: ActivatedRoute,
    private toastr: ToastrService,private router: Router,) {
    const now = new Date();
    this.minDate = now.toISOString().split('T')[0];
    this.userId =sessionStorage.getItem('id')
    this.newTask.userId = this.userId
    
  }

  addTask(){
    console.log(this.newTask)
   
      this.api.addTask(this.newTask).subscribe({
        next:(res:any)=>{
          console.log(res);
          this.toastr.success('Task added successfully')
          this.router.navigate(['tasks'])
        },
        error:(err:any)=>{
          console.log(err);
          this.toastr.error(err)
        }
      })
  }
  // getTask(id:any){
  //   console.log(id);
  //   this.api.getTask(id).subscribe({
  //     next:(res)=>{
  //       console.log(res);
  //       console.log(res.dueDate)
  //       const inputDate = new Date(res.dueDate);
  //       let date = inputDate.toISOString().split('T')[0];
  //       console.log(date)
  //       this.newTask=res
  //       this.newTask.dueDate=inputDate;
        
         
  //     },
  //     error:(err)=>{
  //       console.log(err);
  //     }
  //   })

  // }
}
