import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  constructor(private builder: FormBuilder,
    private api: AuthService,
    private toastr: ToastrService,
    private router:Router){}

    loginform = this.builder.group({

      password: this.builder.control('', Validators.required),
      userName: this.builder.control('', Validators.required),
    });


   
    proceedlogin() {
      if (this.loginform.valid) {
        console.log(this.loginform.value)
        this.api.login(this.loginform.value).subscribe({
          next: (res: any) => {
            console.log("success");
            console.log(res.data);
             sessionStorage.setItem('token', res.data.jwt); 
             sessionStorage.setItem('isLogged', 'true');
             sessionStorage.setItem('id', res.data.user_Id);
             
            this.toastr.success('Loggin success')
             this.router.navigate(['tasks'])
              .then(() => {
              window.location.reload();
              });
          
          },
          error: (err: any) => {
            console.log(err);
            this.toastr.warning('Please enter valid credintial.')
          },
        });
      } else {
        alert("Please fill correctly.")
        this.toastr.warning('Please fill correctly.')
      }
    }
}
