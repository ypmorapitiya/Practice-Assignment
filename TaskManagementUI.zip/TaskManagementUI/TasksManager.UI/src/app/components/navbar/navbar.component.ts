import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent {
  isLogged=sessionStorage.getItem('isLogged')
  
  constructor( private router: Router) {this.isLogged=sessionStorage.getItem('isLogged')}
  ngOnInit(): void {
    this.isLogged=sessionStorage.getItem('isLogged')
  }
  logout() {
    sessionStorage.clear();
    this.isLogged = 'false';
       
        this.router.navigate(['/']).then(() => {
          window.location.reload();
        });
  }
}
