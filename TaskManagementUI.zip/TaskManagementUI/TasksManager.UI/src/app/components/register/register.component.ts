import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {
  user: any = {};
  constructor(
    private builder: FormBuilder,
    private api: AuthService,
    private router: Router ){}

    registerform = this.builder.group({
      
      fullName: this.builder.control('', Validators.required),
      password: this.builder.control('', Validators.required),
      email: this.builder.control('', Validators.required),
    });
    
    register() {
      if (this.registerform.valid) {
        this.api.register(this.registerform.value).subscribe(     
         {
          next:(res:any) =>{
            console.log(res.status)
            if(res.status){
              alert("user registerd")
               this.router.navigate([''])
            }
            else
            alert(res.data)
          },
          error:(err:any)=>{
            console.log(err)
          }
         }
        );
      } else {
        alert("Please enter valid data.")
       
      }
    }
}
