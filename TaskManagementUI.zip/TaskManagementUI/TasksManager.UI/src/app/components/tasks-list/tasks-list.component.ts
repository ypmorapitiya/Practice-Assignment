import { Component, OnInit } from '@angular/core';
import { Task } from 'src/app/models/task.model';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-tasks-list',
  templateUrl: './tasks-list.component.html',
  styleUrls: ['./tasks-list.component.css']
})
export class TasksListComponent implements OnInit {

  tasks: Task[]=[]
  userId:any
  constructor(
    private api: AuthService,
  ) 
  {
    this.userId=sessionStorage.getItem('id')
    this.getAllTasks();
  }
  ngOnInit(): void {
    this.userId=sessionStorage.getItem('id')
    this.getAllTasks();
  }

  getAllTasks(){
    this.api.getAllTasks(this.userId).subscribe({
      next:(res:any)=>{
        console.log(res.data);
         this.tasks=res.data;
      },
      error:(err)=>{
        console.log(err);
      }
    })
  }

  deleteTask(id:any){
    console.log(id)
    this.api.deleteTask(id).subscribe({
      next:(res)=>{
        console.log(res);
        this.getAllTasks()
        
      },
      error:(err)=>{
        console.log(err);
      }
    })
  }

  completeTask(id:any){
    console.log(id)
    this.api.completeTask(id).subscribe({
      next:(res)=>{
        console.log(res);
        this.getAllTasks()
        
      },
      error:(err)=>{
        console.log(err);
      }
    })
  }
}
