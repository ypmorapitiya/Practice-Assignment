import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Task } from 'src/app/models/task.model';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-update-task',
  templateUrl: './update-task.component.html',
  styleUrls: ['./update-task.component.css']
})
export class UpdateTaskComponent {
  minDate: any;
  date:any
 taskId:any
 task: Task={
  taskId: 0,
    taskName: '',
    taskDescription: '',       
    userId:'',
    taskStatus:false

 }
  constructor(private url: ActivatedRoute,private toastr: ToastrService,private router:Router, private api: AuthService){
    const now = new Date();
    this.minDate = now.toISOString().split('T')[0];
  }
  ngOnInit(): void {

    this.taskId=this.url.snapshot.params['id'];

    if(this.taskId != undefined){
        this.getTask(this.taskId)
    }
  }

  getTask(id:any){
    console.log(id);
    this.api.getTask(id).subscribe({
      next:(res:any)=>{
        console.log(res)
        this.task=res.data       
      },
      error:(err)=>{
        console.log(err);
      }
    })

  }

  updateTask(id:any){

    console.log(id)
    this.api.updateTask(id,this.task).subscribe({
      next:(res)=>{
        console.log(res)
        this.toastr.success('updated successfully')
        this.router.navigate(['tasks'])
      },
      error:(err)=>{
        console.log(err)
        this.toastr.error(err.error.message)
      }
    })

    
  }

}
