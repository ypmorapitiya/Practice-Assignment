import { Data } from "@angular/router";

export interface Task {
    taskId: number;
    taskName: string;
    taskDescription: string;
    userId:string;
    taskStatus:boolean;
}