import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Task } from '../models/task.model';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class AuthService {
   headers:any
   token = sessionStorage.getItem('token');
  constructor(private http:HttpClient) { 
    this.token = sessionStorage.getItem('token');
    this.headers = new HttpHeaders({
      'Authorization': `Bearer ${this.token}`
    });
  }
  baseUrl='https://localhost:7243/';

  addTaskUrl= this.baseUrl+ 'Task/addtask';
  updateTaskUrl=this.baseUrl+'Task/updateTask/';
  loginTaskUrl = this.baseUrl+'User/login';
  deleteTaskUrl= this.baseUrl+'Task/deleteTask/';
  getAlltaskUrl=this.baseUrl+'Task/getAllTasks/';
  getTaskByIdUrl=this.baseUrl+'Task/getTask/';
  registerUrl=this.baseUrl+'User/register';
  completeUrl=this.baseUrl+'Task/completeTask/';

  addTask(task:any){
    return this.http.post(this.addTaskUrl,task,{ headers: this.headers })
  }

  login(user:any){
    return this.http.post(this.loginTaskUrl,user)
  }

  register(user:any){
    return this.http.post(this.registerUrl,user)
  }

  deleteTask(id:any){
    return this.http.delete(this.deleteTaskUrl+id,{ headers: this.headers })
  }

  completeTask(id:any){
    return this.http.get(this.completeUrl+id,{ headers: this.headers })
  }

  updateTask(id:any, task:any){
    return this.http.put(this.updateTaskUrl+id,task,{ headers: this.headers })
  }
  getTask(id:any){
    return this.http.get<Task>(this.getTaskByIdUrl+id,{ headers: this.headers })
  }
  getAllTasks(id:any):Observable<Task[]>{
    console.log(this.token)
    return this.http.get<Task[]>(this.getAlltaskUrl+id ,{ headers: this.headers })
  }
}
